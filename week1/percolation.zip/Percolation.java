public class Percolation {

    private int[] grid;
    private final int size;
    private int numberOfOpenSites = 0;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        grid = new int[n * n + 2];
        size = n;

        grid[0] = 0;

        for (int i = 1; i < n * n + 1; i++) {
            grid[i] = -1;
        }

        grid[n * n + 1] = n * n + 1;

    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (row < 1 || row > size) throw new IllegalArgumentException(" Row out of range");
        if (col < 1 || col > size) throw new IllegalArgumentException(" Column out of range");
        int index = getIndex(row, col);

        int[] neighbours = getNeighbours(row, col);

        if (!isOpenIndex(index)) {
            grid[index] = index;
            numberOfOpenSites++;

            for (int neighbor : neighbours) {
                if (isIndexValid(index) && isIndexValid(neighbor)) {
                    if (index > neighbor && isOpenIndex(neighbor)) {
                        grid[index] = grid[neighbor];
                    } else if (index < neighbor && isOpenIndex(neighbor)) {
//                        System.out.println(neighbor);
//                        System.out.println(grid[index]);
                        grid[neighbor] = grid[index];
//                        System.out.println(grid[neighbor]);
                    }
                }
            }
        }

    }

    private boolean isIndexValid(int index) {
        return index >= 0 && index <= size * size + 1;
    }

    private int getIndex(int row, int col) {
        // Returns negative when index row col not correct
        return (row - 1) * size + col;
    }

    private void displayGrid() {

        System.out.printf("%5s", " ");
        for (int i = 1; i < size + 1; i++) {
            System.out.printf("%5d", i);
        }
        System.out.println();
        System.out.printf("%30d", 0);
        for (int i = 1; i < size * size + 1; i++) {

            if (i % size == 1 && i / size != size) {
                System.out.println();
                System.out.printf("%-5d", i / size + 1);
            }

            System.out.printf("%5d", grid[i]);
        }
        System.out.println();
        System.out.printf("%30d%n", grid[size * size + 1]);

    }

    private int[] getNeighbours(int row, int column) {
        int[] neighbours = new int[4];
        neighbours[0] = getIndex(row - 1, column);
        neighbours[1] = getIndex(row, column - 1);
        neighbours[2] = getIndex(row + 1, column);
        neighbours[3] = getIndex(row, column + 1);

        if (row == size) {
            neighbours[2] = size * size + 1;
        }

        if (row == 1) {
            neighbours[0] = 0;
        }
        return neighbours;
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (row < 1 || row > size) throw new IllegalArgumentException(" Row out of range");
        if (col < 1 || col > size) throw new IllegalArgumentException(" Column out of range");
        return isOpenIndex(getIndex(row, col));
    }

    private boolean isOpenIndex(int index) {
        return grid[index] != -1;
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (row < 1 || row > size) throw new IllegalArgumentException(" Row out of range");
        if (col < 1 || col > size) throw new IllegalArgumentException(" Column out of range");
        int index = getIndex(row, col);
        return connected(index, 0);
    }

    private int root(int index) {
        if (grid[index] == -1) return -1;
        while (index != grid[index]) {
            index = grid[index];
        }
        return index;
    }

    private boolean connected(int p, int q) {
        if (grid[p] == -1 || grid[q] == -1) return false;
        return root(p) == root(q);
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return numberOfOpenSites;

    }

    // does the system percolate?
    public boolean percolates() {
        return root(size * size + 1) == 0;
    }

    // test client (optional)
    public static void main(String[] args) {
        Percolation p = new Percolation(6);

//        p.displayGrid();
        p.open(1, 6);
        p.open(2, 6);
        p.open(3, 6);
        p.open(4, 6);
        p.open(5, 6);
        p.open(5, 5);
        p.open(4, 4);
        p.open(3, 4);
        p.open(2, 4);
        p.open(2, 3);
        p.open(2, 2);
        p.open(2, 1);
        p.open(3, 1);
        p.open(4, 1);
        p.open(5, 1);
        p.open(5, 2);
        p.open(6, 2);
        p.open(5, 4);
        System.out.println(p.percolates());
//        System.out.println(p.numberOfOpenSites());

    }
}
