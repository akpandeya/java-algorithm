import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private final double[] probabilities;
    private final int size;
    private final int trials;
    private final double confidence95 = 1.96;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {

        if (n < 0) throw new IllegalArgumentException("n must be > 0");
        if (trials < 0) throw new IllegalArgumentException("trials must be > 0");
        Percolation percolation;
        probabilities = new double[trials];
        size = n;
        this.trials = trials;

        for (int i = 0; i < trials; i++) {
            percolation = new Percolation(n);
            runExperiment(percolation, i);
        }

    }

    private void runExperiment(Percolation p, int j) {
        int i = 0;

        while (!(p.percolates() || i > size * size - 1)) {

            int row = StdRandom.uniform(1, size);
            int col = StdRandom.uniform(1, size);

            p.open(row, col);

            i++;
        }

        System.out.println(i);

        double probability = (double) i / (size * size);

        probabilities[j] = probability;
    }

    // sample mean of percolation threshold
    public double mean() {

        return StdStats.mean(probabilities);
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return StdStats.stddev(probabilities);
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        double s = stddev();

        double m = mean();

        return m - confidence95 * s / Math.sqrt(trials);
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        double s = stddev();

        double m = mean();

        return m + confidence95 * s / Math.sqrt(trials);
    }

    // test client (see below)
    public static void main(String[] args) {
        PercolationStats pStats = new PercolationStats(5, 3);

        System.out.println(pStats.mean());
    }

}
